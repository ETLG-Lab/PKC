function ThetaSolutionVectorwithRandomChoice=IKSOA(n,GoalPosition,Obstacles,margin)
% Updated on 2023/10/06 10:30
% Only consider circular Obstacles
figure;
hold on;

plot(GoalPosition(1),GoalPosition(2),'rp')
Obstacles_center = Obstacles(:, 1:2);
Obstacles_radius = Obstacles(:, 3);
FlagFeasiblewithoutCollision=0;

% tic
while FlagFeasiblewithoutCollision==0
ThetaSolutionVectorwithRandomChoice=AIKSRandom(n,GoalPosition);
StartingLinkPoint=[0;0];
FlagFeasiblewithoutCollision=1;
for k=1:1:n
    EndLinkPoint=StartingLinkPoint+[cos(ThetaSolutionVectorwithRandomChoice(k));sin(ThetaSolutionVectorwithRandomChoice(k))];
    chain=[StartingLinkPoint EndLinkPoint]';
    for m=1:1:size(Obstacles,1)
        if my_CollsionDetection(chain(1, :), chain(2, :), ...
                Obstacles_center(m, :), Obstacles_center(m, :), ...
                Obstacles_radius(m)+margin) == 1
             FlagFeasiblewithoutCollision=0;
             break;
        end  
    end
    StartingLinkPoint=EndLinkPoint;
end
end
% time=toc;

GraphicsObject=nLiknPlot(ThetaSolutionVectorwithRandomChoice);
axis([-n n -n n])
hold on
for ii = 1:size(Obstacles,1)
    jj = 0:0.01:2*pi;
    x = Obstacles_center(ii,1) + Obstacles_radius(ii) * cos(jj);
    y = Obstacles_center(ii,2) + Obstacles_radius(ii) * sin(jj);

   plot(x,y,'k')
   fill(x,y,'k')    
end
xlabel('x');  ylabel('y');
axis equal
end
