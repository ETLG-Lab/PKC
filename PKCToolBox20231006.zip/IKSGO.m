function ThetaSolutionVectorGeneralCasewithGoalOrientation=IKSGO(L,n,GoalPosition,GoalOrientation)
% L: link lenght; n: number of links; n not less than 3
% Quick elbow-down solution by AIKS is used (Updated on 2023/10/01)


nminusoneGoalPosition=[GoalPosition(1)-L*cos(GoalOrientation),GoalPosition(2)-L*sin(GoalOrientation)];

ThetaSolutionVectorGeneralCasewithGoalOrientation=AIKS(L,n-1,nminusoneGoalPosition);

ThetaSolutionVectorGeneralCasewithGoalOrientation=[ThetaSolutionVectorGeneralCasewithGoalOrientation GoalOrientation];