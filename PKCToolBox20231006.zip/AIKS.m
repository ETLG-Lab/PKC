function ThetaSolutionVectorGeneralCase=AIKS(L,n,GoalPosition)
% L: link lenght; n: number of links; n not less than 3
% Quick elbow-down solution is used (Updated on 2023/10/01)

ThetaSolutionVectorGeneralCase=[];
initialPosition=[0 0];
GoalPosition=GoalPosition/L;

    for k=1:1:n-2

[thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds(initialPosition,GoalPosition,n-k+1);

theta=thetalowerbound+0.5*(thetaupperbound-thetalowerbound);
ThetaSolutionVectorGeneralCase=[ThetaSolutionVectorGeneralCase theta];

initialPosition=initialPosition+[cos(theta) sin(theta)];
    end
    
AngleInitialtoGoal=atan2((GoalPosition(1,2)-initialPosition(1,2)), (GoalPosition(1,1)-initialPosition(1,1)));

if AngleInitialtoGoal<0
    AngleInitialtoGoal=AngleInitialtoGoal+2*pi;
end

distanceInitialtoGoal=((initialPosition(1,1)-GoalPosition(1,1))^2+(initialPosition(1,2)-GoalPosition(1,2))^2)^0.5;

Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));

Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
Theta_last=AngleInitialtoGoal+Angleforweist;


ThetaSolutionVectorGeneralCase=[ThetaSolutionVectorGeneralCase Theta_lastsecond Theta_last];