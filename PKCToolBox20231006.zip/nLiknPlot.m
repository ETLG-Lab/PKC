function GraphicsObject=nLiknPlot(configuration)
sizeq=size(configuration);
n=sizeq(2);

hold on
InitialofLink=[0 0];

GraphicsObject=[];

for k=1:1:n
    theta=configuration(k);
    EndofLink=InitialofLink+[cos(theta) sin(theta)];
    Newgraphicsobject=plot([InitialofLink(1) EndofLink(1)],[InitialofLink(2) EndofLink(2)],'b','LineWidth',3);
    GraphicsObject=[GraphicsObject Newgraphicsobject];
    
    InitialofLink=EndofLink;
end
hold off

    