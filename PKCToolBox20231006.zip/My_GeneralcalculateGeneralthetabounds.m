function [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds(initialPosition,goalPosition,numberofLinks)
% 2023、1、17 updated：Redundancy case is covered
% Outputs -8 8 stand for redundancy

distanceInitialtoGoal=((initialPosition(1,1)-goalPosition(1,1))^2+(initialPosition(1,2)-goalPosition(1,2))^2)^0.5;

if numberofLinks>ceil(distanceInitialtoGoal)+1
    thetalowerbound=-8; % Outputs -8 8 stand for redundancy
    thetaupperbound=8; % Outputs -8 8 stand for redundancy
else

AngleInitialtoGoal=atan2((goalPosition(1,2)-initialPosition(1,2)),(goalPosition(1,1)-initialPosition(1,1)));

distanceInitialtoGoal=((initialPosition(1,1)-goalPosition(1,1))^2+(initialPosition(1,2)-goalPosition(1,2))^2)^0.5;

Angleforbounds=acos((distanceInitialtoGoal^2+1^2-(numberofLinks-1)^2)/(2*distanceInitialtoGoal*1));

thetalowerbound=AngleInitialtoGoal-Angleforbounds;

thetaupperbound=AngleInitialtoGoal+Angleforbounds;
end