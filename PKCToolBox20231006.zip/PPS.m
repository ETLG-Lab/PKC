function SolutionforPathPlanningProblem=PPS(n,GoalPosition,Obstacles,margin)
% Updated on 2023/10/06 10:30
% Self-collisions are allowed
ThetaSolutionVectorwithRandomChoice=IKSOA(n,GoalPosition,Obstacles,margin);
figure;
axis equal;
hold on;
plot(GoalPosition(1),GoalPosition(2),'rp')
Obstacles_center = Obstacles(:, 1:2);
Obstacles_radius = Obstacles(:, 3);
for ii = 1:size(Obstacles,1)
    jj = 0:0.01:2*pi;
    x = Obstacles_center(ii,1) + Obstacles_radius(ii) * cos(jj);
    y = Obstacles_center(ii,2) + Obstacles_radius(ii) * sin(jj);
    plot(x,y,'k')
    fill(x,y,'k')    
end
xlabel('x');  ylabel('y');
Root=zeros(1,n); 
Tree=Root;
FatherIndex=0;
FlagPathFound=0;

% tic
while FlagPathFound==0
  if rand>0.9  
      RandomPoint=ThetaSolutionVectorwithRandomChoice;
    else
    for i=1:1:n
        RandomPoint(1,i)=-1*pi+rand*2*pi;
    end
  end
    Pointer=1;
    MinimumDistanceofAngles=0;
    for i=1:1:n
        MinimumDistanceofAngles=MinimumDistanceofAngles+abs(RandomPoint(1,i));
    end

    SizeofTree=size(Tree);
    DimofTree=SizeofTree(1,1);
    for i=2:1:DimofTree
        DistanceofAngles=0;
        for k=1:1:n
            DistanceofAngles=DistanceofAngles+min((abs(RandomPoint(1,k)-Tree(i,k))),(2*pi-abs(RandomPoint(1,k)-Tree(i,k))));
        end

        if DistanceofAngles<MinimumDistanceofAngles
            MinimumDistanceofAngles=DistanceofAngles;
            Pointer=i;
        end
    end

    NewPoint=Tree(Pointer,:);
    LinkofModification=ceil(n*rand);
    Temp=Tree(Pointer,:);
    NewPoint(1,LinkofModification)=(NewPoint(1,LinkofModification)+RandomPoint(1,LinkofModification))/2;
    if sign(Temp(1,LinkofModification))*sign(RandomPoint(1,LinkofModification))==-1
        if abs(Temp(1,LinkofModification))+abs(RandomPoint(1,LinkofModification))>pi
            if NewPoint(1,LinkofModification)>=0
                NewPoint(1,LinkofModification)=NewPoint(1,LinkofModification)-pi;
            else
                NewPoint(1,LinkofModification)=NewPoint(1,LinkofModification)+pi;
            end
        end
    end

newChainsInWorkspace = cumsum([0 cos(NewPoint); 0 sin(NewPoint)]');
FlagCollision = 0;
numChains = size(newChainsInWorkspace,1)-1;

for ii = 1:numChains
    chain = newChainsInWorkspace(ii:ii+1, :);
    for m=1:1:size(Obstacles,1)       
        if my_CollsionDetection(chain(1, :), chain(2, :), ...
                Obstacles_center(m, :), Obstacles_center(m, :), ...
                Obstacles_radius(m)+margin) == 1
            FlagCollision = 1;
            break;
        end 

    end
end

if FlagCollision==0
    Tree=[Tree;NewPoint];
    FatherIndex=[FatherIndex;Pointer];

    x=0;y=0;
    for i=1:1:n
        x=x+cos(NewPoint(1,i));
        y=y+sin(NewPoint(1,i));
    end
    axis([-n n -n n])
    if norm([x,y]-GoalPosition)<0.1
        FlagPathFound=1;
    end
end
end

% toc;
SolutionforPathPlanningProblem=NewPoint;
PreviousPointer=Pointer;

while FatherIndex(Pointer,1)~=0
    PreviousPointer=FatherIndex(Pointer,1);

    SolutionforPathPlanningProblem=[SolutionforPathPlanningProblem;Tree(PreviousPointer,:)];
    Pointer=FatherIndex(Pointer,1);
end

SizeofSolutionforPathPlanningProblem=size(SolutionforPathPlanningProblem);
DimofSolutionforPathPlanningProblem=SizeofSolutionforPathPlanningProblem(1,1);

for i=DimofSolutionforPathPlanningProblem:-1:1
    G=nLiknPlot(SolutionforPathPlanningProblem(i,:));
    axis([-n n -n n])
     pause(0.02);
    delete(G)
end

G=nLiknPlot(SolutionforPathPlanningProblem(i,:));
axis([-n n -n n])
end




