function CollsionDetection = my_CollsionDetection(EndPoint1ofSegment1, EndPoint2ofSegment1, EndPoint1ofSegment2, EndPoint2ofSegment2, Margin)
% Collsion test for Segment 1 and Segment 2; Updated on 2023/10/06 10:30
% Set linkWidth = 0.2
linkWidth = 0.2;
vector_AB = EndPoint2ofSegment1 - EndPoint1ofSegment1;
vector_CD = EndPoint2ofSegment2 - EndPoint1ofSegment2;
vector_AC = EndPoint1ofSegment2 - EndPoint1ofSegment1;

R  = vector_AB * vector_CD';
S1 = vector_AB * vector_AC';
S2 = vector_CD * vector_AC';
D1 = vector_AB * vector_AB';
D2 = vector_CD * vector_CD';


if vector_AB == zeros(size(EndPoint1ofSegment1)) & vector_CD == zeros(size(EndPoint1ofSegment1))
    pointFragmentofSegment1 = 0;
    pointFragmentofSegment2 = 0;

elseif vector_AB == zeros(size(EndPoint1ofSegment1))
    pointFragmentofSegment1 = 0;
    pointFragmentofSegment2 = -S2 / D2;
    pointFragmentofSegment2 = myModify(pointFragmentofSegment2, [0 1]);
elseif vector_CD == zeros(size(EndPoint1ofSegment1))
    pointFragmentofSegment1 = S1 / D1;
    pointFragmentofSegment2 = 0;
    pointFragmentofSegment1 = myModify(pointFragmentofSegment1, [0 1]);

elseif det([D1 R; R D2]) == 0
    pointFragmentofSegment1 = 0;
    pointFragmentofSegment2 = -S2 / D2;

    if pointFragmentofSegment2 ~= myModify(pointFragmentofSegment2, [0 1])
        pointFragmentofSegment2 = myModify(pointFragmentofSegment2, [0 1]);
        pointFragmentofSegment1 = (pointFragmentofSegment2*R+S1) / D1;
        pointFragmentofSegment1 = myModify(pointFragmentofSegment1, [0 1]);
    end

else
    pointFragmentofSegment1 = det([S1 S2; R D2]) / det([D1 R; R D2]);
    pointFragmentofSegment1 = myModify(pointFragmentofSegment1, [0 1]);
    pointFragmentofSegment2 = (pointFragmentofSegment1*R-S2) / D2;
    if pointFragmentofSegment2 ~= myModify(pointFragmentofSegment2, [0 1])
        pointFragmentofSegment2 = myModify(pointFragmentofSegment2, [0 1]);
        pointFragmentofSegment1 = (pointFragmentofSegment2*R+S1) / D1;
        pointFragmentofSegment1 = myModify(pointFragmentofSegment1, [0 1]);
    end
end


minDistance = norm(pointFragmentofSegment1.*vector_AB - pointFragmentofSegment2.*vector_CD - vector_AC);

if minDistance < Margin+linkWidth/2
    CollsionDetection = 1;
else
    CollsionDetection = 0;
end

end

function a = myModify(a, boundary)
if a < min(boundary)
    a = min(boundary);
elseif a > max(boundary)
    a = max(boundary);
end
end