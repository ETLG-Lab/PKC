function IKS 
global current_selected xy_start xdata_start ydata_start  MousebuttonLR centerX centerY  PreviousEndX PreviousEndY ...
    n JointModeVector CurrentObj SensityAngle ModeOpenClosed fixedRightEnd MouseType LeftorRightSolutionforLasttwoLinks ...
    LastFreeEnd FixedModeVector mylinewidth MyEditbox  currentinputtheta CurrentObjIndex xy_current SaturationFlag Previous_selected 

figure('NumberTitle','off','Name','Planar-Kinematic-Chain Toolbox')
hold on;  

mylinewidth=2;
ModeOpenClosed=1; % LXG:  Input 0 or 1 for mode 'open chain' or 'closed chain'
fixedRightEnd=[3 3]; % LXG:  Useful only when mode 'closed chain'
n=5;
SensityAngle=0.1;
LeftorRightSolutionforLasttwoLinks=1; % LXG:  -1 for  elbow-up solution, 1 for  elbow-down solution; Default 1

if ModeOpenClosed==0
   LastFreeEnd=n;
   JointModeVector=zeros(1,n); 
   JointModeVector(1,1)=1; 
   FixedModeVector=zeros(1,LastFreeEnd);
   for i=1:1:n
    plot([(i-1) (i-1)],[0 1],'linewidth',mylinewidth,'ButtonDownFcn',@select);
   end 
   title('Open chain')
end

if ModeOpenClosed==1   
    initialPosition=[0 0]; goalPosition=fixedRightEnd;
    if n>=3
    for i=1:1:(n-2)        
        [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds(initialPosition,goalPosition,(n-i+1));
        EndofLinki=[initialPosition(1,1)+cos((thetalowerbound+thetaupperbound)/2) initialPosition(1,2)+sin((thetalowerbound+thetaupperbound)/2)];
        plot([initialPosition(1,1) EndofLinki(1,1)],[initialPosition(1,2) EndofLinki(1,2)],'linewidth',mylinewidth,'ButtonDownFcn',@select);       
        initialPosition=EndofLinki;
    end
    AngleInitialtoGoal=atan2((fixedRightEnd(1,2)-initialPosition(1,2)), (fixedRightEnd(1,1)-initialPosition(1,1)));
    distanceInitialtoGoal=((initialPosition(1,1)-fixedRightEnd(1,1))^2+(initialPosition(1,2)-fixedRightEnd(1,2))^2)^0.5;
    Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));
    Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
    Theta_last=AngleInitialtoGoal+Angleforweist;                 
    if LeftorRightSolutionforLasttwoLinks==1   
    plot([initialPosition(1,1) initialPosition(1,1)+cos(Theta_lastsecond)],[initialPosition(1,2) initialPosition(1,2)+sin(Theta_lastsecond)],'linewidth',mylinewidth,'ButtonDownFcn',@select);
    plot([fixedRightEnd(1,1)-cos(Theta_last) fixedRightEnd(1,1)], [fixedRightEnd(1,2)-sin(Theta_last) fixedRightEnd(1,2)],'linewidth',mylinewidth,'ButtonDownFcn',@select);
    else
    plot([initialPosition(1,1) initialPosition(1,1)+cos(Theta_last)],[initialPosition(1,2) initialPosition(1,2)+sin(Theta_last)],'linewidth',1,'ButtonDownFcn',@select);
    plot([fixedRightEnd(1,1)-cos(Theta_lastsecond) fixedRightEnd(1,1)], [fixedRightEnd(1,2)-sin(Theta_lastsecond) fixedRightEnd(1,2)],'linewidth',1,'ButtonDownFcn',@select);
    end    
    end
    title('Closed chain')
    LastFreeEnd=n;
    JointModeVector=ones(1,n); 
    FixedModeVector=zeros(1,LastFreeEnd);    
end

xlabel('x')
ylabel('y')
axis([-2,5,-2,5]);
set(gcf,'WindowButtonUpFcn',@change_state,'WindowButtonMotionFcn',@move)
MyEditbox=uicontrol('style','edit',...
 'position',[140 300 60 20],...
 'string',1,...
 'Visible','off');
set([MyEditbox],{'callback'},{@MyEditbox_callback}); 
end
 
function select(obj,event)
global current_selected xy_start xdata_start ydata_start MousebuttonLR centerX centerY PreviousEndX PreviousEndY ...
    CurrentObjIndex MouseType JointModeVector ModeOpenClosed n FixedModeVector LastFreeEnd fixedRightEnd MyEditbox YCurrentdate XCurrentdate Previous_selected

MousebuttonLR=event.Button;
MouseType=get(gcf,'SelectionType');
if strcmp(MouseType,'alt')==1 && MousebuttonLR==1
    set(MyEditbox,'Visible','on');
end
set(obj,'Selected','on');
current_selected=obj;
Previous_selected=current_selected;
xy_start=get(gca,'CurrentPoint');
xdata_start=get(obj,'xdata');
ydata_start=get(obj,'ydata');
CurrentObjIndex=get(obj,'SeriesIndex'); 
centerX=xdata_start(1,1);
centerY=ydata_start(1,1); 

if MousebuttonLR==1
    PreviousEndX=xdata_start(1,2); 
    PreviousEndY=ydata_start(1,2);
end
if strcmp(MouseType,'open')==1 && MousebuttonLR==2
   JointModeVector=zeros(1,n); 
   JointModeVector(1,1)=1;
   ModeOpenClosed=0;
   title('Open chain')
end    
    % LXG: Below lock and unlock a link
if ModeOpenClosed==1
   if strcmp(MouseType,'open')==1 && MousebuttonLR==1             
            % LXG: Below lock
      if FixedModeVector(1,CurrentObjIndex)==0 && CurrentObjIndex==LastFreeEnd
         FixedModeVector(1,CurrentObjIndex)=1;
         LastFreeEnd=CurrentObjIndex-1
         fixedRightEnd=[xdata_start(1,1) ydata_start(1,1)];        
      else            
            % LXG: Below unlock
         if FixedModeVector(1,CurrentObjIndex)==1 && CurrentObjIndex==(LastFreeEnd+1)                
            FixedModeVector(1,CurrentObjIndex)=0;
            LastFreeEnd=CurrentObjIndex
            fixedRightEnd=[xdata_start(1,2) ydata_start(1,2)];        
         end   
      end
    end        
 end   
end


function change_state(obj,event)
global current_selected n JointModeVector CurrentObjIndex MyEditbox
if current_selected~=0
   hCurrent = findobj('SeriesIndex',CurrentObjIndex);
   Xstate=get(hCurrent,'xdata');
   Ystate=get(hCurrent,'ydata');
   Theta=atan2((Ystate(1,2)-Ystate(1,1)),(Xstate(1,2)-Xstate(1,1)));
   set(MyEditbox,'string',num2str(Theta));
   set(current_selected,'Selected','off');
   current_selected=0;    
   ThetaSolutionVector=[];
   for i=1:1:n
       h = findobj('SeriesIndex',i);  
       Xstate=get(h,'xdata');Ystate=get(h,'ydata');
       Theta=atan2((Ystate(1,2)-Ystate(1,1)),(Xstate(1,2)-Xstate(1,1))); 
       ThetaSolutionVector=[ThetaSolutionVector, Theta];
    end
    ThetaSolutionVector   
end
end


function move(obj,event)
 global current_selected xy_start xdata_start ydata_start  MousebuttonLR centerX centerY PreviousEndX PreviousEndY ...
    n JointModeVector CurrentObjIndex SensityAngle ModeOpenClosed fixedRightEnd MouseType LeftorRightSolutionforLasttwoLinks ...
    LastFreeEnd fixedRightEnd xy_current SaturationFlag
if current_selected~=0
    xy_current=get(gca,'CurrentPoint');
    dx=xy_current(1)-xy_start(1);
    dy=xy_current(3)-xy_start(3);       
  if MousebuttonLR==1       
       if JointModeVector(1,CurrentObjIndex)==0       
   set(current_selected,'xdata',xdata_start+dx,'ydata',ydata_start+dy);
       end
  end   
  if MousebuttonLR==2  
       if JointModeVector(1,CurrentObjIndex)==0       
           CurrentTheta=atan2((ydata_start(1,2)-ydata_start(1,1)),(xdata_start(1,2)-xdata_start(1,1)));
       if ((centerX-PreviousEndX)^2+(centerY-PreviousEndY)^2)>0.6       
          set(current_selected,'xdata',xdata_start+dx,'ydata',ydata_start+dy);
       else
          set(current_selected,'xdata',[PreviousEndX PreviousEndX+cos(CurrentTheta)],'ydata',[PreviousEndY PreviousEndY+sin(CurrentTheta)]);       
          JointModeVector(1,CurrentObjIndex)=1;      
          if ModeOpenClosed==0
             ProductElementsofJointModeVector=1;
             for i=1:1:n
                 ProductElementsofJointModeVector=ProductElementsofJointModeVector*JointModeVector(1,i);
             end
             if ProductElementsofJointModeVector==1
                ModeOpenClosed=1;
                title('Closed chain')
             if CurrentObjIndex==n
                fixedRightEnd=[PreviousEndX+cos(CurrentTheta) PreviousEndY+sin(CurrentTheta)];
                 DistancetoOrigin=((fixedRightEnd(1,1))^2+(fixedRightEnd(1,2)^2))^0.5;
                 formatSpec = 'Right end is [%4.4f %4.4f] and distance to origin is %4.4f\n';
                 fprintf(formatSpec,fixedRightEnd(1,1), fixedRightEnd(1,2), DistancetoOrigin)
             end  
             end
          end      
       end
       end
   end
 if MousebuttonLR==3  
    Xstate=get(current_selected,'xdata');Ystate=get(current_selected,'ydata');
   if ModeOpenClosed==0   
   set(current_selected,'xdata',((Xstate-centerX)*cos(SensityAngle*dy)-(Ystate-centerY)*sin(SensityAngle*dy)+centerX),'ydata',((Xstate-centerX)*sin(SensityAngle*dy)+(Ystate-centerY)*cos(SensityAngle*dy)+centerY));   
   NumberofRightLinked=0;    
   flag=0; currentP=CurrentObjIndex;
   while flag==0
        if currentP<n
            if JointModeVector(1,(currentP+1))==1 
            NumberofRightLinked=NumberofRightLinked+1;
            currentP=currentP+1;
            else
             flag=1;   
            end
        else
            flag=1;
        end
    end
    NumberofRightLinked;  
    for i=(CurrentObjIndex+1):1:(CurrentObjIndex+NumberofRightLinked)
        h = findobj('SeriesIndex',i);
        Xstate=get(h,'xdata');Ystate=get(h,'ydata');         
        set(h,'xdata',((Xstate-centerX)*cos(SensityAngle*dy)-(Ystate-centerY)*sin(SensityAngle*dy)+centerX),'ydata',((Xstate-centerX)*sin(SensityAngle*dy)+(Ystate-centerY)*cos(SensityAngle*dy)+centerY));   
    end
   end
   if ModeOpenClosed==1    
      if CurrentObjIndex<=LastFreeEnd-2
         X=get(current_selected,'xdata'); Y=get(current_selected,'ydata');
         PreviousEnd=([X(1,2),Y(1,2)]); 
         for i=CurrentObjIndex:1:(LastFreeEnd-2)
             h = findobj('SeriesIndex',i);
             if i==CurrentObjIndex
                Xstate=get(h,'xdata');Ystate=get(h,'ydata');
                CurrentTheta=atan2((Ystate(1,2)-Ystate(1,1)),(Xstate(1,2)-Xstate(1,1)));    
                [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds([Xstate(1,1) Ystate(1,1)],fixedRightEnd,(LastFreeEnd-i+1));

 if thetalowerbound==-8 | thetaupperbound==8 % -8 8 redundant 
        SaturationFlag=0;
 else    
     if abs(thetaupperbound)<pi | abs(thetalowerbound)<pi
        if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
           SaturationFlag=0; 
        else
          if (CurrentTheta+SensityAngle*dy)<thetalowerbound
           SaturationFlag=-1; 
          end
          if (CurrentTheta+SensityAngle*dy)>thetaupperbound
           SaturationFlag=1;    
          end
        end
     end
if thetaupperbound>=pi
    if CurrentTheta<thetaupperbound-2*pi
        CurrentTheta=CurrentTheta+2*pi;
    end    
    if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
       SaturationFlag=0; 
    else
      if (CurrentTheta+SensityAngle*dy)<thetalowerbound
        SaturationFlag=-1; 
      end
      if (CurrentTheta+SensityAngle*dy)>thetaupperbound
        SaturationFlag=1;    
      end
   end
end
if thetalowerbound<=-1*pi
    if CurrentTheta>thetalowerbound+2*pi
        CurrentTheta=CurrentTheta-2*pi;
    end    
    if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
       SaturationFlag=0; 
    else
       if (CurrentTheta+SensityAngle*dy)<thetalowerbound
        SaturationFlag=-1; 
       end
       if (CurrentTheta+SensityAngle*dy)>thetaupperbound
        SaturationFlag=1;    
       end
   end
end
end

if SaturationFlag==0    
    set(h,'xdata',((Xstate-Xstate(1,1))*cos(SensityAngle*dy)-(Ystate-Ystate(1,1))*sin(SensityAngle*dy)+Xstate(1,1)),'ydata',((Xstate-Xstate(1,1))*sin(SensityAngle*dy)+(Ystate-Ystate(1,1))*cos(SensityAngle*dy)+Ystate(1,1)));
else
    if SaturationFlag==-1    
    set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(thetalowerbound)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(thetalowerbound)]);
    end
    if SaturationFlag==1    
    set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(thetaupperbound)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(thetaupperbound)]);
    end
end

    
Xstate=get(h,'xdata');Ystate=get(h,'ydata');  
PreviousEnd=([Xstate(1,2),Ystate(1,2)]);
end

if i>CurrentObjIndex && i<=LastFreeEnd-2
    [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds([PreviousEnd(1,1) PreviousEnd(1,2)],fixedRightEnd,(LastFreeEnd-i+1));
    set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos((thetalowerbound+thetaupperbound)/2)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin((thetalowerbound+thetaupperbound)/2)]);    
    Xstate=get(h,'xdata');Ystate=get(h,'ydata');  
    PreviousEnd=([Xstate(1,2),Ystate(1,2)]);
end     
end          
EndofLastThird=PreviousEnd;                   
AngleInitialtoGoal=atan2((fixedRightEnd(1,2)-EndofLastThird(1,2)), (fixedRightEnd(1,1)-EndofLastThird(1,1)));
distanceInitialtoGoal=((PreviousEnd(1,1)-fixedRightEnd(1,1))^2+(PreviousEnd(1,2)-fixedRightEnd(1,2))^2)^0.5;
Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));
Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
Theta_last=AngleInitialtoGoal+Angleforweist;        
          
if LeftorRightSolutionforLasttwoLinks==1   
h = findobj('SeriesIndex',(LastFreeEnd-1));
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos(Theta_lastsecond)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin(Theta_lastsecond)]);
h = findobj('SeriesIndex',LastFreeEnd);
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_last) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_last) fixedRightEnd(1,2)]);
else   
h = findobj('SeriesIndex',(LastFreeEnd-1));
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos(Theta_last)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin(Theta_last)]);
h = findobj('SeriesIndex',LastFreeEnd);
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_lastsecond) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_lastsecond) fixedRightEnd(1,2)]);    
end
      end
if CurrentObjIndex==(LastFreeEnd-1)
   if LeftorRightSolutionforLasttwoLinks==1 && dy>0  
      LeftorRightSolutionforLasttwoLinks=-1; 
      h = findobj('SeriesIndex',(LastFreeEnd-1));
      Xstate=get(h,'xdata');Ystate=get(h,'ydata');         
AngleInitialtoGoal=atan2((fixedRightEnd(1,2)-Ystate(1,1)), (fixedRightEnd(1,1)-Xstate(1,1)));
distanceInitialtoGoal=((Xstate(1,1)-fixedRightEnd(1,1))^2+(Ystate(1,1)-fixedRightEnd(1,2))^2)^0.5;
Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));
Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
Theta_last=AngleInitialtoGoal+Angleforweist; 
set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(Theta_last)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(Theta_last)]);
h = findobj('SeriesIndex',LastFreeEnd);
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_lastsecond) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_lastsecond) fixedRightEnd(1,2)]);
    end
   if LeftorRightSolutionforLasttwoLinks==-1 && dy<0  
      LeftorRightSolutionforLasttwoLinks=1;
      h = findobj('SeriesIndex',(LastFreeEnd-1));
Xstate=get(h,'xdata');Ystate=get(h,'ydata');          
AngleInitialtoGoal=atan2((fixedRightEnd(1,2)-Ystate(1,1)), (fixedRightEnd(1,1)-Xstate(1,1)));
distanceInitialtoGoal=((Xstate(1,1)-fixedRightEnd(1,1))^2+(Ystate(1,1)-fixedRightEnd(1,2))^2)^0.5;
Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));
Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
Theta_last=AngleInitialtoGoal+Angleforweist; 
set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(Theta_lastsecond)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(Theta_lastsecond)]);
h = findobj('SeriesIndex',LastFreeEnd);
Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_last) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_last) fixedRightEnd(1,2)]);
    end
   end
   end  
end
end
end


function MyEditbox_callback(hObj,evnt)  %CYJ Added on 20230302
   global current_selected xy_start xdata_start ydata_start  MousebuttonLR centerX centerY PreviousEndX PreviousEndY ...
    n JointModeVector CurrentObjIndex SensityAngle ModeOpenClosed fixedRightEnd MouseType LeftorRightSolutionforLasttwoLinks ...
    LastFreeEnd fixedRightEnd SaturationFlag MyEditbox currentinputtheta mylinewidth Previous_selected  xy_current
   currentinputtheta=str2double(get(MyEditbox,'string'));
  if ModeOpenClosed==0
       if (currentinputtheta>=2*pi)||(currentinputtheta<=-2*pi)
            currentinputtheta=mod(currentinputtheta,2*pi);
            if currentinputtheta>pi
                currentinputtheta=currentinputtheta-2*pi;
            end
       else
            if  currentinputtheta>pi
            currentinputtheta=currentinputtheta-2*pi;
            end
            if currentinputtheta<-pi
            currentinputtheta=currentinputtheta+2*pi;
            end
       end
     Xstate=get(Previous_selected,'xdata');
     Ystate=get(Previous_selected,'ydata');
     h = findobj('SeriesIndex',CurrentObjIndex);
     set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(currentinputtheta)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(currentinputtheta)]);
     NumberofRightLinked=0;    
     flag=0; currentP=CurrentObjIndex;
     while flag==0
        if currentP<n
            if JointModeVector(1,(currentP+1))==1 
            NumberofRightLinked=NumberofRightLinked+1;
            currentP=currentP+1;
            else
             flag=1;   
            end
        else
            flag=1;
        end
     end
     
     for i=(CurrentObjIndex+1):1:(CurrentObjIndex+NumberofRightLinked)
         h = findobj('SeriesIndex',i);
         Xstate=get(h,'xdata');Ystate=get(h,'ydata');        
         set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(currentinputtheta)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(currentinputtheta)]);
     end
     set(MyEditbox,'Visible','off');
end
if ModeOpenClosed==1
   Xstate=get(Previous_selected,'xdata');
   Ystate=get(Previous_selected,'ydata');
   CurrentTheta=atan2((Ystate(1,2)-Ystate(1,1)),(Xstate(1,2)-Xstate(1,1))); 
   [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds([Xstate(1,1) Ystate(1,1)],fixedRightEnd,(LastFreeEnd-CurrentObjIndex+1));
 if (currentinputtheta>thetaupperbound)||(currentinputtheta<thetalowerbound)
       disp('Please enter a valid value.')
 else  
    xy_current=get(gca,'CurrentPoint');
    dx=xy_current(1)-xy_start(1);
    dy=xy_current(3)-xy_start(3);  
    if CurrentObjIndex<=LastFreeEnd-2
          X=get(Previous_selected,'xdata');
          Y=get(Previous_selected,'ydata');
          PreviousEnd=([X(1,2),Y(1,2)]);         
     for i=CurrentObjIndex:1:(LastFreeEnd-2)
          h = findobj('SeriesIndex',i);
         if i==CurrentObjIndex
            Xstate=get(h,'xdata');Ystate=get(h,'ydata');
   if thetalowerbound==-8 | thetaupperbound==8 
        SaturationFlag=0;
   else 
     if abs(thetaupperbound)<pi | abs(thetalowerbound)<pi
        if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
           SaturationFlag=0; 
        else
          if (CurrentTheta+SensityAngle*dy)<thetalowerbound
           SaturationFlag=-1; 
          end
          if (CurrentTheta+SensityAngle*dy)>thetaupperbound
           SaturationFlag=1;    
          end
        end
     end
if thetaupperbound>=pi
    if CurrentTheta<thetaupperbound-2*pi
        CurrentTheta=CurrentTheta+2*pi;
    end    
    if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
       SaturationFlag=0; 
    else
      if (CurrentTheta+SensityAngle*dy)<thetalowerbound
        SaturationFlag=-1; 
      end
      if (CurrentTheta+SensityAngle*dy)>thetaupperbound
        SaturationFlag=1;    
      end
   end
end

if thetalowerbound<=-1*pi
    if CurrentTheta>thetalowerbound+2*pi
        CurrentTheta=CurrentTheta-2*pi;
    end    
    if (CurrentTheta+SensityAngle*dy)<thetaupperbound && (CurrentTheta+SensityAngle*dy)>thetalowerbound
       SaturationFlag=0; 
    else
       if (CurrentTheta+SensityAngle*dy)<thetalowerbound
        SaturationFlag=-1; 
       end
       if (CurrentTheta+SensityAngle*dy)>thetaupperbound
        SaturationFlag=1;    
       end
   end
end
end   
      if SaturationFlag==0  
         set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(currentinputtheta)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(currentinputtheta)]);     
      else
          if SaturationFlag==-1    
             set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(thetalowerbound)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(thetalowerbound)]);
          end
          if SaturationFlag==1    
             set(h,'xdata',[Xstate(1,1) Xstate(1,1)+cos(thetaupperbound)],'ydata',[Ystate(1,1) Ystate(1,1)+sin(thetaupperbound)]);               
          end
      end
          Xstate=get(h,'xdata');Ystate=get(h,'ydata');  
          PreviousEnd=([Xstate(1,2),Ystate(1,2)]);
end
      if i>CurrentObjIndex && i<=LastFreeEnd-2
         [thetalowerbound,thetaupperbound]=My_GeneralcalculateGeneralthetabounds([PreviousEnd(1,1) PreviousEnd(1,2)],fixedRightEnd,(LastFreeEnd-i+1));
         set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos((thetalowerbound+thetaupperbound)/2)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin((thetalowerbound+thetaupperbound)/2)]);    
         Xstate=get(h,'xdata');Ystate=get(h,'ydata');  
         PreviousEnd=([Xstate(1,2),Ystate(1,2)]);
      end     
end        
     EndofLastThird=PreviousEnd;                  
     AngleInitialtoGoal=atan2((fixedRightEnd(1,2)-EndofLastThird(1,2)), (fixedRightEnd(1,1)-EndofLastThird(1,1)));
     distanceInitialtoGoal=((PreviousEnd(1,1)-fixedRightEnd(1,1))^2+(PreviousEnd(1,2)-fixedRightEnd(1,2))^2)^0.5;
     Angleforweist=acos((distanceInitialtoGoal^2)/(2*distanceInitialtoGoal));
     Theta_lastsecond=AngleInitialtoGoal-Angleforweist;
     Theta_last=AngleInitialtoGoal+Angleforweist;                  
 if LeftorRightSolutionforLasttwoLinks==1   
    h = findobj('SeriesIndex',(LastFreeEnd-1));
    Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
    set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos(Theta_lastsecond)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin(Theta_lastsecond)]);
    h = findobj('SeriesIndex',LastFreeEnd);
    Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
    set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_last) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_last) fixedRightEnd(1,2)]);
 else   
    h = findobj('SeriesIndex',(LastFreeEnd-1));
    Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
    set(h,'xdata',[PreviousEnd(1,1) PreviousEnd(1,1)+cos(Theta_last)],'ydata',[PreviousEnd(1,2) PreviousEnd(1,2)+sin(Theta_last)]);
    h = findobj('SeriesIndex',LastFreeEnd);
    Xstate=get(h,'xdata');Ystate=get(h,'ydata'); 
    set(h,'xdata',[fixedRightEnd(1,1)-cos(Theta_lastsecond) fixedRightEnd(1,1)],'ydata',[fixedRightEnd(1,2)-sin(Theta_lastsecond) fixedRightEnd(1,2)]);    
 end
end
  set(MyEditbox,'Visible','off');
 end
 end
end
% Above CYJ Added about Editbox Input